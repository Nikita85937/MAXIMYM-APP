package com.maximum.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
